<?php
require __DIR__ . '/_boot.php';
require_admin();

$TYPE = ['sale' => 'بيع', 'expense' => 'مصروف', 'deposit' => 'إيداع'];

if (isset($_GET['csv'])) {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="joya-ledger.csv"');
    echo "\xEF\xBB\xBF";
    $out = fopen('php://output', 'w');
    fputcsv($out, ['date', 'type', 'product', 'qty', 'amount', 'note']);
    $names = array_column(jread('products'), 'name', 'id');
    foreach (jread('ledger') as $r) {
        fputcsv($out, [$r['at'], $r['type'], $names[$r['pid'] ?? ''] ?? '', $r['qty'] ?? '', $r['amount'], $r['note'] ?? '']);
    }
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_ok()) { flash('انتهت الجلسة.', 'err'); redirect('ledger.php'); }
    $action = (string)($_POST['action'] ?? '');
    if ($action === 'add') {
        $type = (string)($_POST['type'] ?? 'sale');
        $amount = (float)($_POST['amount'] ?? 0);
        $note = mb_substr(trim((string)($_POST['note'] ?? '')), 0, 120);
        if (!isset($TYPE[$type]) || $amount <= 0) {
            flash('اختر النوع واكتب مبلغا أكبر من صفر.', 'err');
        } else {
            $row = ['id' => new_id('l'), 'at' => date('c'), 'type' => $type, 'amount' => $amount, 'note' => $note];
            if ($type === 'sale' && !empty($_POST['pid'])) {
                $pid = (string)$_POST['pid'];
                $qty = max(1, (int)($_POST['qty'] ?? 1));
                $row['pid'] = $pid; $row['qty'] = $qty;
                jmodify('products', function (array &$d) use ($pid, $qty) {
                    foreach ($d as &$p) if ($p['id'] === $pid) $p['stock'] = max(0, (int)$p['stock'] - $qty);
                });
            }
            jmodify('ledger', function (array &$d) use ($row) { $d[] = $row; });
            flash('تم تسجيل الحركة.');
        }
    } elseif ($action === 'delete') {
        $id = (string)($_POST['id'] ?? '');
        jmodify('ledger', function (array &$d) use ($id) { $d = array_values(array_filter($d, fn($r) => $r['id'] !== $id)); });
        flash('تم حذف الحركة. لم يتغير المخزون.');
    }
    redirect('ledger.php');
}

$s = ledger_sums();
$rows = array_reverse(jread('ledger'));
$prods = products(false);
$names = array_column($prods, 'name', 'id');
admin_head('الأرصدة', 'ledger');
?>
<div class="stats num" style="margin-top:8px">
  <div class="stat big"><small>الرصيد الحالي</small><strong class="<?= $s['balance'] >= 0 ? 'pos' : 'neg' ?>"><?= money($s['balance']) ?></strong></div>
  <div class="stat"><small>إيرادات</small><strong><?= money($s['sale']) ?></strong></div>
  <div class="stat"><small>مصروفات</small><strong><?= money($s['exp']) ?></strong></div>
  <div class="stat"><small>إيداعات</small><strong><?= money($s['dep']) ?></strong></div>
</div>

<div class="two" style="margin-top:14px">
  <form class="acard" method="post">
    <h2 style="font-size:19px;margin-bottom:8px">تسجيل حركة</h2>
    <?= csrf_field() ?><input type="hidden" name="action" value="add">
    <div class="seg">
      <?php foreach ($TYPE as $k => $v): ?><label><input type="radio" name="type" value="<?= $k ?>" <?= $k === 'sale' ? 'checked' : '' ?>><span><?= e($v) ?></span></label><?php endforeach; ?>
    </div>
    <label class="field">المنتج (للبيع فقط، يخصم من المخزون)
      <select name="pid"><option value="">بدون منتج</option><?php foreach ($prods as $p): ?><option value="<?= e($p['id']) ?>"><?= e($p['name']) ?></option><?php endforeach; ?></select></label>
    <div class="row2">
      <label class="field">الكمية<input name="qty" type="number" min="1" value="1" inputmode="numeric"></label>
      <label class="field">المبلغ (<?= e(cfg('currency')) ?>)<input name="amount" type="number" min="1" step="any" inputmode="decimal" required></label>
    </div>
    <label class="field">البيان / اسم العميل<input name="note"></label>
    <button class="btn primary block" type="submit">حفظ الحركة</button>
    <p class="hint">إيداع = رأس مال أو أي مبلغ يدخل للرصيد. الطلبات المؤكدة تُسجل هنا تلقائيا.</p>
  </form>

  <div class="acard">
    <h2 style="font-size:19px;margin-bottom:8px">سجل الحركات</h2>
    <?php if (!$rows): ?><p class="hint">لا توجد حركات بعد. سجل إيداع رأس المال أو أول بيع لتبدأ متابعة الرصيد.</p><?php else: ?>
    <div class="scroll"><table class="num"><thead><tr><th>التاريخ</th><th>النوع</th><th>التفاصيل</th><th>المبلغ</th><th></th></tr></thead><tbody>
    <?php foreach (array_slice($rows, 0, 100) as $r): $det = ($r['type'] === 'sale' && !empty($r['pid']) ? ($names[$r['pid']] ?? 'منتج') . ' × ' . (int)$r['qty'] . ' ' : '') . ($r['note'] ?? ''); ?>
      <tr><td><?= e(date('d/m', strtotime($r['at']))) ?></td><td><?= e($TYPE[$r['type']] ?? '') ?></td><td><?= e($det) ?></td>
      <td class="<?= $r['type'] === 'expense' ? 'neg' : 'pos' ?>"><?= $r['type'] === 'expense' ? '−' : '+' ?><?= money($r['amount']) ?></td>
      <td><form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= e($r['id']) ?>"><button class="btn sm danger" type="submit">حذف</button></form></td></tr>
    <?php endforeach; ?></tbody></table></div>
    <p style="margin:12px 0 0"><a class="btn sm" href="ledger.php?csv=1">تصدير CSV</a></p>
    <?php endif; ?>
  </div>
</div>
<?php admin_foot();
