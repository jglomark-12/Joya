<?php
require dirname(__DIR__) . '/lib.php';

function admin_ok(): bool
{
    return !empty($_SESSION['admin']);
}

function require_admin(): void
{
    if (!admin_ok()) redirect('index.php');
}

function ledger_sums(): array
{
    $s = ['dep' => 0, 'sale' => 0, 'exp' => 0, 'units' => 0];
    foreach (jread('ledger') as $e) {
        $a = (float)$e['amount'];
        if ($e['type'] === 'sale') { $s['sale'] += $a; $s['units'] += (int)($e['qty'] ?? 0); }
        elseif ($e['type'] === 'expense') $s['exp'] += $a;
        else $s['dep'] += $a;
    }
    $s['balance'] = $s['dep'] + $s['sale'] - $s['exp'];
    return $s;
}

function admin_head(string $title, string $active): void
{
    $new = count(array_filter(jread('orders'), fn($o) => $o['status'] === 'new'));
    $tabs = [
        'index' => ['index.php', 'اللوحة'],
        'orders' => ['orders.php', 'الطلبات' . ($new ? " ($new)" : '')],
        'products' => ['products.php', 'المنتجات'],
        'ledger' => ['ledger.php', 'الأرصدة'],
        'social' => ['social.php', 'النشر'],
    ];
    ?><!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="robots" content="noindex,nofollow">
<title><?= e($title) ?> | لوحة التحكم</title>
<link rel="stylesheet" href="../assets/style.css">
</head>
<body>
<div class="wrap">
<header class="top">
  <a class="logo" href="index.php"><b>Joya</b> <small>لوحة التحكم</small></a>
  <a class="btn sm" href="../index.php">المتجر</a>
  <a class="btn sm" href="logout.php">خروج</a>
</header>
<nav class="tabs" aria-label="أقسام اللوحة">
<?php foreach ($tabs as $k => [$href, $label]): ?><a class="<?= $k === $active ? 'on' : '' ?>" href="<?= $href ?>"><?= e($label) ?></a><?php endforeach; ?>
</nav>
<?php if ($f = flash()): ?><div class="flash <?= $f['t'] === 'err' ? 'err' : '' ?>" role="status"><?= e($f['m']) ?></div><?php endif;
}

function admin_foot(): void
{
    echo "</div>\n</body>\n</html>\n";
}
