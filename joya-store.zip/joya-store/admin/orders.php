<?php
require __DIR__ . '/_boot.php';
require_admin();

function customer_wa(string $phone, string $text): string
{
    $n = preg_replace('/\D/', '', $phone);
    if (strpos($n, '00') === 0) $n = substr($n, 2);
    elseif (strpos($n, '0') === 0) $n = '20' . substr($n, 1);
    return 'https://wa.me/' . $n . '?text=' . rawurlencode($text);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_ok()) { flash('انتهت الجلسة.', 'err'); redirect('orders.php'); }
    $id = (string)($_POST['id'] ?? '');
    $action = (string)($_POST['action'] ?? '');
    $order = null;
    foreach (jread('orders') as $o) if ($o['id'] === $id) $order = $o;
    if ($order && $action === 'confirm' && $order['status'] === 'new') {
        foreach ($order['items'] as $it) {
            jmodify('products', function (array &$d) use ($it) {
                foreach ($d as &$p) if ($p['id'] === $it['pid']) $p['stock'] = max(0, (int)$p['stock'] - (int)$it['qty']);
            });
            jmodify('ledger', function (array &$d) use ($it, $order) {
                $d[] = ['id' => new_id('l'), 'at' => date('c'), 'type' => 'sale', 'pid' => $it['pid'], 'qty' => (int)$it['qty'],
                        'amount' => $it['price'] * $it['qty'], 'note' => 'طلب ' . strtoupper(substr($order['id'], 0, 6)) . ' - ' . $order['name'], 'order' => $order['id']];
            });
        }
        jmodify('orders', function (array &$d) use ($id) { foreach ($d as &$o) if ($o['id'] === $id) $o['status'] = 'confirmed'; });
        flash('تم تأكيد الطلب وخصم المخزون وتسجيل المبيعات.');
    } elseif ($order && $action === 'cancel' && $order['status'] === 'new') {
        jmodify('orders', function (array &$d) use ($id) { foreach ($d as &$o) if ($o['id'] === $id) $o['status'] = 'cancelled'; });
        flash('تم إلغاء الطلب.');
    }
    redirect('orders.php');
}

$orders = array_reverse(jread('orders'));
$label = ['new' => 'جديد', 'confirmed' => 'مؤكد', 'cancelled' => 'ملغي'];
admin_head('الطلبات', 'orders');
if (!$orders) echo '<div class="panel empty" style="grid-column:auto">لا توجد طلبات بعد. تظهر هنا فور أن يؤكد عميل طلبه من المتجر.</div>';
foreach ($orders as $o): ?>
<div class="acard">
  <header><b><?= e($o['name']) ?> <span class="hint num">#<?= e(strtoupper(substr($o['id'], 0, 6))) ?></span></b><span class="pill"><?= e($label[$o['status']] ?? $o['status']) ?></span></header>
  <div class="hint num"><?= e(date('d/m/Y H:i', strtotime($o['at']))) ?> | <?= e($o['phone']) ?></div>
  <div style="margin:6px 0"><?= e($o['addr']) ?><?= !empty($o['note']) ? '<div class="hint">ملاحظات: ' . e($o['note']) . '</div>' : '' ?></div>
  <div class="sum num">
    <?php foreach ($o['items'] as $i): ?><div><span><?= e($i['name']) ?> × <?= (int)$i['qty'] ?></span><span><?= money($i['price'] * $i['qty']) ?></span></div><?php endforeach; ?>
    <div class="total"><span>الإجمالي (شامل الشحن)</span><span><?= money($o['total']) ?></span></div>
  </div>
  <div class="row2">
    <a class="btn sm" target="_blank" rel="noopener" href="<?= e(customer_wa($o['phone'], 'أهلا ' . $o['name'] . '، بخصوص طلبك رقم ' . strtoupper(substr($o['id'], 0, 6)) . ' من ' . cfg('store_name'))) ?>">راسل العميل</a>
    <?php if ($o['status'] === 'new'): ?>
    <form method="post" style="display:contents"><?= csrf_field() ?><input type="hidden" name="id" value="<?= e($o['id']) ?>">
      <button class="btn sm primary" name="action" value="confirm" type="submit">تأكيد الطلب</button>
    </form>
    <?php endif; ?>
  </div>
  <?php if ($o['status'] === 'new'): ?>
  <form method="post" style="margin-top:8px"><?= csrf_field() ?><input type="hidden" name="id" value="<?= e($o['id']) ?>"><button class="btn sm danger" name="action" value="cancel" type="submit">إلغاء الطلب</button></form>
  <?php endif; ?>
</div>
<?php endforeach;
admin_foot();
