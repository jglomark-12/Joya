<?php
require __DIR__ . '/_boot.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_ok()) { flash('انتهت الجلسة.', 'err'); redirect('products.php'); }
    $action = (string)($_POST['action'] ?? '');
    $id = (string)($_POST['id'] ?? '');
    $data = [
        'name'   => mb_substr(trim((string)($_POST['name'] ?? '')), 0, 100),
        'cat'    => mb_substr(trim((string)($_POST['cat'] ?? '')), 0, 40) ?: 'عام',
        'price'  => max(0, (float)($_POST['price'] ?? 0)),
        'was'    => max(0, (float)($_POST['was'] ?? 0)),
        'stock'  => max(0, (int)($_POST['stock'] ?? 0)),
        'desc'   => mb_substr(trim((string)($_POST['desc'] ?? '')), 0, 500),
        'active' => !empty($_POST['active']),
    ];
    try {
        if ($action === 'create') {
            if ($data['name'] === '' || $data['price'] <= 0) throw new RuntimeException('اكتب اسم المنتج وسعرا أكبر من صفر.');
            $data['id'] = new_id('p');
            $data['img'] = save_upload($_FILES['img'] ?? ['error' => UPLOAD_ERR_NO_FILE]) ?? '';
            jmodify('products', function (array &$d) use ($data) { $d[] = $data; });
            flash('تمت إضافة المنتج.');
        } elseif ($action === 'save') {
            if ($data['name'] === '' || $data['price'] <= 0) throw new RuntimeException('اكتب اسم المنتج وسعرا أكبر من صفر.');
            $new = save_upload($_FILES['img'] ?? ['error' => UPLOAD_ERR_NO_FILE]);
            $rm = !empty($_POST['rm_img']);
            $old = jmodify('products', function (array &$d) use ($id, $data, $new, $rm) {
                foreach ($d as &$p) if ($p['id'] === $id) {
                    $old = $p['img'] ?? '';
                    $img = $new ?? ($rm ? '' : $old);
                    $p = array_merge($p, $data, ['img' => $img]);
                    return ($new !== null || $rm) ? $old : '';
                }
                return '';
            });
            if ($old) delete_upload($old);
            flash('تم حفظ التعديلات.');
        } elseif ($action === 'delete') {
            if (empty($_POST['confirm'])) throw new RuntimeException('فعّل مربع تأكيد الحذف أولا.');
            $old = jmodify('products', function (array &$d) use ($id) {
                $img = '';
                foreach ($d as $k => $p) if ($p['id'] === $id) { $img = $p['img'] ?? ''; unset($d[$k]); }
                $d = array_values($d);
                return $img;
            });
            if ($old) delete_upload($old);
            flash('تم حذف المنتج.');
        }
    } catch (RuntimeException $ex) {
        flash($ex->getMessage(), 'err');
    }
    redirect('products.php');
}

$list = products(false);
admin_head('المنتجات', 'products');

function product_fields(array $p = []): void { ?>
  <label class="field">اسم المنتج<input name="name" required value="<?= e($p['name'] ?? '') ?>"></label>
  <div class="row2">
    <label class="field">القسم<input name="cat" value="<?= e($p['cat'] ?? '') ?>" placeholder="مثال: إكسسوارات"></label>
    <label class="field">المخزون<input name="stock" type="number" min="0" inputmode="numeric" value="<?= (int)($p['stock'] ?? 0) ?>"></label>
  </div>
  <div class="row2">
    <label class="field">السعر (<?= e(cfg('currency')) ?>)<input name="price" type="number" min="1" step="any" inputmode="decimal" required value="<?= e($p['price'] ?? '') ?>"></label>
    <label class="field">السعر قبل الخصم (اختياري)<input name="was" type="number" min="0" step="any" inputmode="decimal" value="<?= !empty($p['was']) ? e($p['was']) : '' ?>"></label>
  </div>
  <label class="field">الوصف<textarea name="desc"><?= e($p['desc'] ?? '') ?></textarea></label>
  <label class="field">صورة المنتج (JPG أو PNG أو WEBP)<input type="file" name="img" accept="image/jpeg,image/png,image/webp"></label>
<?php }
?>
<details class="panel" <?= $list ? '' : 'open' ?>>
  <summary class="btn primary" style="list-style:none">إضافة منتج جديد</summary>
  <form method="post" enctype="multipart/form-data" style="margin-top:12px">
    <?= csrf_field() ?><input type="hidden" name="action" value="create">
    <?php product_fields(); ?>
    <label class="field" style="grid-auto-flow:column;justify-content:start;align-items:center"><input type="checkbox" name="active" value="1" checked style="width:auto;min-height:0"> ظاهر في المتجر</label>
    <button class="btn primary block" type="submit">إضافة المنتج</button>
  </form>
</details>

<?php foreach ($list as $p): ?>
<form class="acard" method="post" enctype="multipart/form-data">
  <?= csrf_field() ?><input type="hidden" name="id" value="<?= e($p['id']) ?>">
  <header>
    <b><?= e($p['name']) ?></b>
    <?php if (!empty($p['img'])): ?><img class="thumb" src="../uploads/<?= e($p['img']) ?>" alt=""><?php else: ?><span class="pill">بدون صورة</span><?php endif; ?>
  </header>
  <?php product_fields($p); ?>
  <?php if (!empty($p['img'])): ?><label class="field" style="grid-auto-flow:column;justify-content:start;align-items:center"><input type="checkbox" name="rm_img" value="1" style="width:auto;min-height:0"> حذف الصورة الحالية</label><?php endif; ?>
  <label class="field" style="grid-auto-flow:column;justify-content:start;align-items:center"><input type="checkbox" name="active" value="1" <?= !empty($p['active']) ? 'checked' : '' ?> style="width:auto;min-height:0"> ظاهر في المتجر</label>
  <div class="row2">
    <button class="btn primary" name="action" value="save" type="submit">حفظ</button>
    <button class="btn danger" name="action" value="delete" type="submit">حذف المنتج</button>
  </div>
  <label class="field" style="grid-auto-flow:column;justify-content:start;align-items:center;margin:8px 0 0"><input type="checkbox" name="confirm" value="1" style="width:auto;min-height:0"> أؤكد الحذف</label>
</form>
<?php endforeach; ?>
<?php admin_foot();
