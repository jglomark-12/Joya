<?php
require __DIR__ . '/_boot.php';
require_admin();

$url = site_url();
$ps = products();
$p1 = $ps[0] ?? ['name' => 'منتج مميز', 'price' => 0, 'was' => 0];
$p2 = $ps[1] ?? $p1;
$tags = '#جويا #متجر_اونلاين #تسوق_اونلاين #هدايا #اكسسوارات #مصر #الدفع_عند_الاستلام #توصيل_لكل_المحافظات';
$posts = [
    ['فيسبوك: افتتاح المتجر', "أخيرا " . cfg('store_name') . " اتفتح!\nهدايا وإكسسوارات مختارة بعناية، والدفع عند الاستلام وتوصيل لكل المحافظات.\nتصفح المنتجات واطلب من هنا:\n$url\n$tags"],
    ['إنستجرام: منتج اليوم', "منتج اليوم: {$p1['name']}\nبسعر " . money($p1['price']) . (!empty($p1['was']) ? ' بدل ' . money($p1['was']) : '') . "\nاطلب من الرابط في البايو.\n$tags"],
    ['واتساب: رسالة للمعارف', "أهلا، فتحت متجر " . cfg('store_name') . " للهدايا والإكسسوارات.\nالدفع عند الاستلام والتوصيل متاح.\nشوف المنتجات: $url"],
    ['تيك توك: فكرة فيديو', "فيديو 15 ثانية: فتح علبة طلب من " . cfg('store_name') . " مع لقطة قريبة لـ {$p2['name']}.\nالنص على الشاشة: \"هدية جاهزة بـ " . money($p2['price']) . "\".\nالتعليق: الرابط في البايو.\n$tags"],
    ['ستوري: عرض 24 ساعة', "عرض اليوم فقط: شحن مجاني للطلبات فوق " . money(cfg('free_from')) . ".\nادخل على الرابط في البايو."],
    ['جروبات فيسبوك وماركت بليس', "متاح الآن في " . cfg('store_name') . ': ' . implode('، ', array_map(fn($x) => $x['name'] . ' ' . money($x['price']), array_slice($ps, 0, 4))) . ".\nالدفع عند الاستلام. الطلب من الرابط: $url"],
];
$plan = ['افتتاح: منشور فيسبوك + ستوري + رسالة واتساب لـ 20 شخصا', 'منتج اليوم على إنستجرام', 'فيديو تيك توك لفتح علبة الطلب', 'نشر في 3 جروبات فيسبوك مناسبة', 'ستوري: عرض الشحن المجاني', 'صورة قبل وبعد أو استخدام المنتج', 'شارك رأي عميل (بعد إذنه)', 'منتج اليوم الثاني + استطلاع رأي', 'فيديو تيك توك ثاني', 'نشر في جروبات وماركت بليس', 'ستوري عرض محدود', 'مقارنة منتجين وسؤال المتابعين', 'منشور هدايا للمناسبات', 'راجع أكثر منشور تفاعلا وكرر نوعه'];

admin_head('النشر', 'social');
?>
<div class="flash">انسخ كل منشور وانشره من حسابك. الرابط داخل المنشورات هو رابط موقعك الحالي: <span class="num" dir="ltr"><?= e($url) ?></span></div>
<h2 style="font-size:20px;margin:16px 0 8px">منشورات جاهزة</h2>
<?php foreach ($posts as $i => [$n, $t]): ?>
<div class="post"><header><b><?= e($n) ?></b><button class="btn sm" type="button" data-copy="p<?= $i ?>">نسخ</button></header><pre id="p<?= $i ?>"><?= e($t) ?></pre></div>
<?php endforeach; ?>
<div class="two" style="margin-top:14px">
  <div class="acard"><h2 style="font-size:19px;margin-bottom:8px">قنوات مجانية</h2>
    <ul style="margin:0;padding-inline-start:20px;display:grid;gap:6px"><li>صفحة فيسبوك + Marketplace</li><li>إنستجرام والرابط في البايو</li><li>تيك توك للفيديوهات القصيرة</li><li>واتساب بيزنس (كتالوج وحالة)</li><li>قناة تيليجرام للعروض</li></ul></div>
  <div class="acard"><h2 style="font-size:19px;margin-bottom:8px">جدول 14 يوم</h2>
    <div class="scroll"><table style="min-width:0"><tbody><?php foreach ($plan as $i => $r): ?><tr><td class="num" style="width:40px"><b><?= $i + 1 ?></b></td><td><?= e($r) ?></td></tr><?php endforeach; ?></tbody></table></div></div>
</div>
<script>
document.addEventListener('click',function(ev){
  var b=ev.target.closest('[data-copy]'); if(!b) return;
  var t=document.getElementById(b.getAttribute('data-copy')).textContent;
  function done(ok){ b.textContent=ok?'تم النسخ':'انسخ يدويا'; setTimeout(function(){b.textContent='نسخ'},1600); }
  function fb(){ var a=document.createElement('textarea'); a.value=t; document.body.appendChild(a); a.select(); var ok=false; try{ok=document.execCommand('copy')}catch(e){} a.remove(); done(ok); }
  if(navigator.clipboard&&navigator.clipboard.writeText){ navigator.clipboard.writeText(t).then(function(){done(true)},fb); } else fb();
});
</script>
<?php admin_foot();
