<?php
require __DIR__ . '/_boot.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !admin_ok()) {
    $fails = (int)($_SESSION['fails'] ?? 0);
    if (!csrf_ok()) {
        flash('انتهت الجلسة، حاول مرة أخرى.', 'err');
    } elseif ($fails >= 8) {
        flash('محاولات كثيرة. حاول لاحقا.', 'err');
    } elseif (password_verify((string)($_POST['password'] ?? ''), (string)cfg('admin_hash'))) {
        session_regenerate_id(true);
        $_SESSION['admin'] = true;
        $_SESSION['fails'] = 0;
        redirect('index.php');
    } else {
        $_SESSION['fails'] = $fails + 1;
        sleep(1);
        flash('كلمة السر غير صحيحة.', 'err');
    }
    redirect('index.php');
}

if (!admin_ok()) {
    ?><!doctype html>
<html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow">
<title>دخول لوحة التحكم</title><link rel="stylesheet" href="../assets/style.css"></head>
<body><div class="wrap" style="max-width:420px">
<header class="top"><a class="logo" href="../index.php"><b>Joya</b> <small>لوحة التحكم</small></a></header>
<?php if ($f = flash()): ?><div class="flash err"><?= e($f['m']) ?></div><?php endif; ?>
<form class="panel" method="post">
  <?= csrf_field() ?>
  <label class="field">كلمة السر<input type="password" name="password" required autocomplete="current-password" autofocus></label>
  <button class="btn primary block" type="submit">دخول</button>
</form></div></body></html>
<?php
    exit;
}

$s = ledger_sums();
$orders = jread('orders');
$new = array_filter($orders, fn($o) => $o['status'] === 'new');
$low = array_filter(products(false), fn($p) => $p['stock'] <= 3);

admin_head('اللوحة', 'index');
?>
<div class="stats num" style="margin-top:8px">
  <div class="stat big"><small>الرصيد الحالي</small><strong class="<?= $s['balance'] >= 0 ? 'pos' : 'neg' ?>"><?= money($s['balance']) ?></strong></div>
  <div class="stat"><small>إيرادات المبيعات</small><strong><?= money($s['sale']) ?></strong></div>
  <div class="stat"><small>المصروفات</small><strong><?= money($s['exp']) ?></strong></div>
  <div class="stat"><small>قطع مباعة</small><strong><?= (int)$s['units'] ?></strong></div>
</div>

<div class="panel">
  <h2 style="font-size:19px;margin-bottom:6px">طلبات جديدة: <span class="num"><?= count($new) ?></span></h2>
  <?php if ($new): foreach (array_slice(array_reverse($new), 0, 5) as $o): ?>
    <div class="line" style="grid-template-columns:1fr auto"><div><b><?= e($o['name']) ?></b><div class="hint num"><?= money($o['total']) ?> | <?= e(date('d/m H:i', strtotime($o['at']))) ?></div></div><a class="btn sm" href="orders.php">فتح</a></div>
  <?php endforeach; else: ?><p class="hint">لا توجد طلبات جديدة.</p><?php endif; ?>
</div>

<div class="panel">
  <h2 style="font-size:19px;margin-bottom:6px">منتجات على وشك النفاد</h2>
  <?php if ($low): foreach ($low as $p): ?>
    <div class="line" style="grid-template-columns:1fr auto"><span><?= e($p['name']) ?></span><span class="pill num"><?= $p['stock'] <= 0 ? 'نفد' : 'باقي ' . (int)$p['stock'] ?></span></div>
  <?php endforeach; else: ?><p class="hint">كل المنتجات متوفرة بكمية كافية.</p><?php endif; ?>
</div>
<?php admin_foot();
